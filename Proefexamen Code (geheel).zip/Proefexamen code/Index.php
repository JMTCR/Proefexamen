<!DOCTYPE html>
<html>
<head>
	<meta name="author" content="Justin Mank">
	<title>INLOGGEN</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<ul>
		<li><a class="active" href="hoofdpagina.html">Hoofdpagina</a></li>
		<li><a href="verkiezing.php">verkiezingen</a></li>
		<li><a href="info.html">informatie</a></li>
		<li><a href="index.php">Inloggen</a></li>
	</ul>
	
     <form action="login.php" method="post">
     	<h2>INLOGGEN</h2>
     	<?php if (isset($_GET['error'])) { ?>
     		<p class="error"><?php echo $_GET['error']; ?></p>
     	<?php } ?>
     	<label>Naam</label>
     	<input type="text" name="naam" placeholder="Naam"><br>

     	<label>BSNnummer</label>
     	<input type="password" name="BSNnummer" placeholder="BSNnummer"><br>

     	<button type="submit">Inloggen</button>
		<a href="signup.php" class="ca">Account aanmaken?</a>
     </form>
</body>
</html>