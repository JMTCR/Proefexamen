<!DOCTYPE html>
<html>
<head>
	<meta name="author" content="Justin Mank">
	<title>Account maken</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<ul>
  <li><a class="active" href="hoofdpagina.html">Hoofdpagina</a></li>
  <li><a href="verkiezing.php">verkiezingen</a></li>
  <li><a href="info.html">informatie</a></li>
  <li><a href="inloggen.php">Inloggen</a></li>
</ul>

     <form action="signup-check.php" method="post">
     	<h2>Account maken</h2>
     	<?php if (isset($_GET['error'])) { ?>
     		<p class="error"><?php echo $_GET['error']; ?></p>
     	<?php } ?>

          <?php if (isset($_GET['success'])) { ?>
               <p class="success"><?php echo $_GET['success']; ?></p>
          <?php } ?>

          <label>Naam</label>
          <?php if (isset($_GET['name'])) { ?>
               <input type="text" 
                      name="naam" 
                      placeholder="Naam"
                      value="<?php echo $_GET['naam']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="naam" 
                      placeholder="Naam"><br>
          <?php }?>

     	<label>BSNnummer</label>
     	<input type="password" 
                 name="BSNnummer" 
                 placeholder="BSNnummer"><br>

          <label>Herhaal BSNnummer</label>
          <input type="password" 
                 name="Redo_BSN" 
                 placeholder="Herhaal BSNnummer"><br>

     	<button type="submit">Aanmaken</button>
          <a href="index.php" class="ca">Heeft u al een account?</a>
     </form>
</body>
</html>