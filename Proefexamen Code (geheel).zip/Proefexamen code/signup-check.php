<!DOCTYPE html>
<html>
<head>
	<meta name="author" content="Justin Mank">
</head>
</html>

<?php 
session_start(); 
include "db_conn.php";

if (isset($_POST['naam']) && isset($_POST['BSNnummer'])
	&& isset($_POST['Redo_BSN'])){

	function validate($data){
       $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}

	$naam = validate($_POST['naam']);
	$BSN = validate($_POST['BSNnummer']);
	$Redo_BSN = validate($_POST['Redo_BSN']);
	
	$user_data = 'naam'. $naam. 'BSN='. $BSN;


	if (empty($naam)) {
		header("Location: signup.php?error=Naam is verplicht&$user_data");
	    exit();
	}else if(empty($BSN)){
        header("Location: signup.php?error=BSN is verplicht&$user_data");
	    exit();
	}
	else if(empty($Redo_BSN)){
        header("Location: signup.php?error=BSN herhaling is verplicht&$user_data");
	    exit();
	}

	else if($BSN !== $Redo_BSN){
        header("Location: signup.php?error=U BSN bevestiging klopt niet&$user_data");
	    exit();
	}

	else{

		// hashing the password
        $BSN = md5($BSN);

	    $sql = "SELECT * FROM users WHERE naam='$naam' ";
		$result = mysqli_query($conn, $sql);

		if (mysqli_num_rows($result) > 0) {
			header("Location: signup.php?error=Dit BSNnummer is al geregistreerd bij ons&$user_data");
	        exit();
		}else {
           $sql2 = "INSERT INTO users(naam, BSNnummer) VALUES('$naam', '$BSN')";
           $result2 = mysqli_query($conn, $sql2);
           if ($result2) {
           	 header("Location: signup.php?success=U account is successful aangemaakt");
	         exit();
           }else {
	           	header("Location: signup.php?error=unknown error occurred&$user_data");
		        exit();
           }
		}
	}
	
}else{
	header("Location: signup.php");
	exit();
}