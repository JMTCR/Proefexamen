<html>
	<head>
		<title>verkiezing</title>
		<link rel="stylesheet" type="text/css" href="stijl.css" />
		<!-----author = Logan Overduin----->
		<ul>
  <li><a class="active" href="hoofdpagina.html">Hoofdpagina</a></li>
  <li><a href="verkiezing.php">verkiezingen</a></li>
  <li><a href="infopagina.html">informatie</a></li>
  <li><a href="inloggen.php">Inloggen</a></li>
</ul>
	</head>
	<body>
		
	
		<h1>verkiezingen</h1>
		<?php
			$date = date('2022-08-11');
			$time = date('00:00:00');
			$date_today = $date	.' '. $time;
			echo "je kan pas stemmen vanaf " .$date_today;
		?>
		<h1>tijd tot de verkiezingen starten</h1>
			<script type="text/javascript">
			var count_id = "<?php echo $date_today; ?>";
			var countDownDate = new Date(count_id).getTime();
			
			var x = setInterval(function(){
				
			var now = new Date().getTime();
			
			var distance = countDownDate - now;
			
			var days = Math.floor(distance/(1000 * 60 * 60 * 24));
			var hours = Math.floor((distance%(1000*60*60*24))/(1000*60*60));
			var minutes = Math.floor((distance%(1000*60*60))/(1000*60));
			var seconds = Math.floor((distance%(1000*60))/1000);
			
			document.getElementById("demo").innerHTML = days + "d " + hours + "h " +
			minutes + "m " + seconds + "s ";
			if(distance<0){
				clearInterval(x);
				document.getElementById("demo").innerHTML="EXPIRED";
			}
		},1000);
			</script>
			<?php
			echo '<p id="demo" style="font-size:30px";></p>';
			?>
			
		<h2> op 11 augustus kan je stemmen op verschillende partijen:</h2></br></br></br>
		<p>VVD: Een brede en sterke middengroep is cruciaal voor een stabiele samenleving.</br>
		Maar juist de middengroepen hebben het moeilijk. Daarom willen wij hen steunen.</br>
		</br>
		De hoogste inkomens profiteren sterker van economische groei en de laagste inkomens</br> 
		kunnen een beroep doen op uitkeringen en toeslagen. De middeninkomens vallen daar vaak</br> 
		net buiten. Zij zien ondertussen wel hun lasten stijgen, terwijl de groei van hun loon</br> 
		of pensioen achterblijft.</br>
		</br>
		Wij kiezen er bewust voor om de middengroepen meer te laten profiteren van de groeiende</br>
		welvaart. Daarom verlagen wij voor hen verschillende belastingen en beperken we de stijging</br>
		van vaste lasten als wonen, zorg en energie. Als de overheid geld overhoudt, moet dat</br>
		bovendien automatisch naar belastingverlaging voor de middeninkomens en het mkb gaan.</br></br>
		<center><img src="VVD.png" width="200" height="150"></br></center>
		<a href="error404.html">stem hier op VVD</a> </br></br></br>
		PVV: De Partij voor de Vrijheid (PVV) is een populistische partij, met zowel conservatieve,</br>
		liberale, rechtse als linkse standpunten. De PVV is op 22 februari 2006 geregistreerd bij</br>
		de Kiesraad door Geert Wilders, na zijn vertrek bij de VVD. Politiek leider is sinds 2006 Geert Wilders.</br>
		</br>
		De PVV heeft sinds de Tweede Kamerverkiezingen van 2021 17 zetels in de Tweede Kamer. De </br>
		partij heeft 5 zetels in de Eerste Kamer en 0 zetels in het Europees Parlement.</br>
		</br>
		De PVV is onderdeel van de oppositie en is dat, met uitzondering van de periode 2010-2012 </br>
		waarin het het kabinet Rutte I gedoogde, altijd geweest.</br></br>
		<center><img src="PVV.jpg" width="200" height="150"></br></center>
		<a href="error404.html">stem hier op PVV</a> </br></br></br>
		PVDA: Werk, werk, werk. Daar staat de PvdA voor. Daarom verhogen we het minimumloon naar </br>
		&euro;14 per uur, en komt er een werkgarantie voor iedereen die zijn of haar baan verliest </br>
		door de coronacrisis. We verhogen de maandelijkse AOW-uitkering. Gelijke beloning voor vrouwen </br>
		en mannen wordt wettelijk vastgelegd. Bij ziekte of tegenslag krijgen ook jongeren en zzp'ers </br>
		recht op bescherming.</br></br>
		Goede, liefdevolle zorg moet beschikbaar en betaalbaar zijn voor iedereen. Daarom schaffen </br>
		we het eigen risico af, en verlagen we de maandelijkse zorgpremie. Zorgverzekeraars mogen </br>
		geen winst meer uitkeren aan aandeelhouders. We schaffen de BTW op groente en fruit af, en </br>
		belonen de medewerkers in de zorg met meer salaris.</br></br>
		Iedereen heeft recht op een fijn en betaalbaar huis. Daarom komt er een minister voor Wonen,</br>
		die 100.000 nieuwe, betaalbare woningen per jaar gaat bouwen. We schaffen de verhuurdersheffing</br>
		af, en introduceren een 'Prins Bernhard'-belasting voor pandjesbazen en beleggers. Er komen ook </br>
		stevige boetes voor huisjesmelkers die te hoge huren vragen.</br></br>
		Alle kinderen verdienen het beste onderwijs. Daarom wordt de kinderopvang vervangen door een </br>
		voorschool, die voor alle kinderen gratis is. De basisbeurs voor studenten komt terug. Kinderen </br>
		in arme gezinnen krijgen meer steun voor sport of muziekles. En we lanceren een groot offensief</br>
		om kinderen weer aan het lezen te krijgen.</br></br>
		Dit moeten we ook kunnen betalen. Daarom gaat Nederland eindelijk een eerlijke bijdrage vragen </br>
		van miljonairs en multinationals. Er komen hogere belastingen voor milieuvervuilende bedrijven, </br>
		en bedrijven als Google en Facebook moeten een digi-taks gaan afdragen. Voor mensen die méér dan </br>
		&euro;150.000 per jaar verdienen komt er een nieuw toptarief.</br></br>
		<center><img src="PVDA.jpg" width="200" height="150"></br> </center>
		<a href="error404.html">stem hier op PVDA</a> </br></br></br>
		D66: Laat iedereen vrij,maar niemand vallen.</br>
		Je bent pas vrij als iedereen dat is. D66 gelooft in gelijke kansen voor iedereen en hulp voor wie het nodig heeft.</br></br>
		<center><img src="D66.jpg" width="200" height="150"></br></center>
		<a href="error404.html">stem hier op D66</a> </br></br></br>
		</p>
	</body>
</html>