<!DOCTYPE html>
<html>
<head>
	<meta name="author" content="Justin Mank">
</head>
</html>

<?php 
session_start(); 
include "db_conn.php";

if (isset($_POST['naam']) && isset($_POST['BSNnummer'])) {

	function validate($data){
       $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}

	$naam = validate($_POST['naam']);
	$BSN = validate($_POST['BSNnummer']);

	if (empty($naam)) {
		header("Location: index.php?error=Naam is verplicht");
	    exit();
	}else if(empty($BSN)){
        header("Location: index.php?error=BSNnummer is verplicht");
	    exit();
	}else{
		$sql = "SELECT * FROM users WHERE naam='$naam' AND BSNnummer='$BSN'";

		$result = mysqli_query($conn, $sql);

		if (mysqli_num_rows($result) === 1) {
			$row = mysqli_fetch_assoc($result);
            if ($row['naam'] === $naam && $row['BSNnummer'] === $BSN) {
            	$_SESSION['naam'] = $row['naam'];
            	$_SESSION['BSNnummer'] = $row['BSNnummer'];
            	header("Location: verkiezing.php");
		        exit();
            }else{
				header("Location: index.php?error=Incorrecte naam or BSN");
		        exit();
			}
		}else{
			header("Location: index.php?error=Incorrecte Naam or BSN");
	        exit();
		}
	}
	
}else{
	header("Location: index.php");
	exit();
}